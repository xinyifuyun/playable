window.boot = function () {


    var settings = window._CCSettings;
    window._CCSettings = undefined;
    // cc.macro.DebugMode = true;

    function addDownloadHandlers() {
        cc.loader.addDownloadHandlers({
            png: downloadImage,
            jpg: downloadImage,
            jpeg: downloadImage,
        });

        cc.loader.addDownloadHandlers({
            json: downloadText,
            plist: downloadText,
            txt: downloadText
        });

        cc.loader.addDownloadHandlers({
            mp3: downloadAudio,
            ogg: downloadAudio,
            wav: downloadAudio,
            m4a: downloadAudio
        });
        cc.loader.addDownloadHandlers({
            bin: downloadBin,
        });
    }


    // image downloader
    function downloadImage(item, callback, isCrossOrigin, img) {
        img = img || new Image();
        if (img.complete && img.naturalWidth > 0) {
            return img;
        } else {
            function loadCallback() {
                img.removeEventListener('load', loadCallback);
                img.removeEventListener('error', errorCallback);
                img.id = item.id;
                callback(null, img);
            }

            function errorCallback() {
                img.removeEventListener('load', loadCallback);
                img.removeEventListener('error', errorCallback);

                callback(new Error('can not find img ' + item.url));
            }
            img.addEventListener('load', loadCallback);
            img.addEventListener('error', errorCallback);
            img.src = window.resMap[item.url];
        }
    }
    function downloadBin(item, callback) {
        if (!item || !window.resMap[item.url]) {
            callback(new Error('can not find text ' + item.url));
        } else {
            callback(null, b64Encode(window.resMap[item.url]));
        }
    }
    // text downloader
    function downloadText(item, callback) {
        if (!item || !window.resMap[item.url]) {
            callback(new Error('can not find text ' + item.url));
        } else {
            callback(null, window.resMap[item.url]);
        }
    }

    function addLoaderHandlers() {
        cc.loader.addLoadHandlers({
            plist: loadPlist,
        })
    }
    function loadPlist(item) {
        if (item.content) {
            return item.content;
        }
        else {
            return new Error('Plist Loader: Parse [' + item.id + '] failed');
        }
    }
    addLoaderHandlers();

    function loadDomAudio(item, callback) {
        console.log("domaudio");

        var dom = document.createElement('audio');
        dom.muted = true;
        dom.muted = false;
        dom.src = window.resMap[item.url];
        var clearEvent = function () {
            clearTimeout(timer);
            dom.removeEventListener("canplaythrough", success, false);
            dom.removeEventListener("error", failure, false);
            if (cc.sys.__audioSupport.USE_LOADER_EVENT)
                dom.removeEventListener(cc.sys.__audioSupport.USE_LOADER_EVENT, success, false);
        };
        var timer = setTimeout(function () {
            if (dom.readyState === 0)
                failure();
            else
                success();
        }, 8000);
        var success = function () {
            clearEvent();
            callback(null, dom);
        };
        var failure = function () {
            clearEvent();
            var message = 'load audio failure - ' + item.url;
            cc.log(message);
            callback(message);
        };
        dom.addEventListener("canplaythrough", success, false);
        dom.addEventListener("error", failure, false);
        if (cc.sys.__audioSupport.USE_LOADER_EVENT)
            dom.addEventListener(cc.sys.__audioSupport.USE_LOADER_EVENT, success, false);
    }

    function b64Encode(base64Str) {
        var bString = window.atob(base64Str);
        var len = bString.length;
        var arr = new Uint8Array(len);
        while (len--) {
            arr[len] = bString.charCodeAt(len);
        }
        return arr;
    }

    function loadWebAudio(item, callback, context) {
        if (!context)
            callback(new Error("no web audio context"));

        if (!item || !item.url) {
            callback(new Error("unfound " + item.url));
        }
        var data = window.resMap[item.url].replace('data:audio/mpeg;base64,', '');
        data = b64Encode(data);
        context["decodeAudioData"](data.buffer, function (buffer) {
            //success
            callback(null, buffer);
        }, function () {
            //error
            callback('decode error - ' + item.id, null);
        });
    }


    function downloadAudio(item, callback) {
        var __audioSupport = cc.sys.__audioSupport;
        var formatSupport = __audioSupport.format;
        var context = __audioSupport.context;
        if (formatSupport.length === 0) {
            return new Error("audio not supported on this browser!");
        }

        var loader;
        if (!__audioSupport.WEB_AUDIO) {
            // If WebAudio is not supported, load using DOM mode
            loader = loadDomAudio;
        } else {
            var loadByDeserializedAudio = item._owner instanceof cc.AudioClip;
            if (loadByDeserializedAudio) {
                loader = (item._owner.loadMode === cc.AudioClip.LoadMode.WEB_AUDIO) ? loadWebAudio : loadDomAudio;
            } else {
                loader = (item.urlParam && item.urlParam['useDom']) ? loadDomAudio : loadWebAudio;
            }
        }
        loader(item, callback, context);
    }

    addDownloadHandlers();
    if (!settings.debug) {
        var uuids = settings.uuids;

        var rawAssets = settings.rawAssets;
        var assetTypes = settings.assetTypes;
        var realRawAssets = settings.rawAssets = {};
        for (var mount in rawAssets) {
            var entries = rawAssets[mount];
            var realEntries = realRawAssets[mount] = {};
            for (var id in entries) {
                var entry = entries[id];
                var type = entry[1];
                // retrieve minified raw asset
                if (typeof type === 'number') {
                    entry[1] = assetTypes[type];
                }
                // retrieve uuid
                realEntries[uuids[id] || id] = entry;
            }
        }

        var scenes = settings.scenes;
        for (var i = 0; i < scenes.length; ++i) {
            var scene = scenes[i];
            if (typeof scene.uuid === 'number') {
                scene.uuid = uuids[scene.uuid];
            }
        }

        var packedAssets = settings.packedAssets;
        for (var packId in packedAssets) {
            var packedIds = packedAssets[packId];
            for (var j = 0; j < packedIds.length; ++j) {
                if (typeof packedIds[j] === 'number') {
                    packedIds[j] = uuids[packedIds[j]];
                }
            }
        }

        var subpackages = settings.subpackages;
        for (var subId in subpackages) {
            var uuidArray = subpackages[subId].uuids;
            if (uuidArray) {
                for (var k = 0, l = uuidArray.length; k < l; k++) {
                    if (typeof uuidArray[k] === 'number') {
                        uuidArray[k] = uuids[uuidArray[k]];
                    }
                }
            }
        }
    }
    function setLoadingDisplay() {
        cc.director.once(cc.Director.EVENT_AFTER_SCENE_LAUNCH, function () {
            var loading = document.getElementById('loading');
            loading.style.display = "none";
        });
    }
    var onStart = function () {
        cc.loader.downloader._subpackages = settings.subpackages;

        cc.view.enableRetina(true);
        cc.view.resizeWithBrowserSize(true);

        setLoadingDisplay();

        if (cc.sys.isMobile) {
            if (settings.orientation === 'landscape') {
                cc.view.setOrientation(cc.macro.ORIENTATION_LANDSCAPE);
            } else if (settings.orientation === 'portrait') {
                cc.view.setOrientation(cc.macro.ORIENTATION_PORTRAIT);
            }
            cc.view.enableAutoFullScreen([
                cc.sys.BROWSER_TYPE_BAIDU,
                cc.sys.BROWSER_TYPE_WECHAT,
                cc.sys.BROWSER_TYPE_MOBILE_QQ,
                cc.sys.BROWSER_TYPE_MIUI,
            ].indexOf(cc.sys.browserType) < 0);
        }

        if (cc.sys.isBrowser && cc.sys.os === cc.sys.OS_ANDROID) {
            cc.macro.DOWNLOAD_MAX_CONCURRENT = 2;
        }

        function loadScene(launchScene) {
            cc.director.loadScene(launchScene,
                function (err) {
                    if (!err) {
                        if (cc.sys.isBrowser) {
                            // show canvas
                            var canvas = document.getElementById('GameCanvas');
                            canvas.style.visibility = '';
                            var div = document.getElementById('GameDiv');
                            if (div) {
                                div.style.backgroundImage = '';
                            }
                        }
                        cc.loader.onProgress = null;
                        // console.log('Success to load scene: ' + launchScene);
                    } else if (CC_BUILD) {
                        setTimeout(function () {
                            loadScene(launchScene);
                        }, 1000);
                    }
                }
            );

        }

        var launchScene = settings.launchScene;


        // load scene
        loadScene(launchScene);

    };

    // jsList
    var jsList = settings.jsList;

    // var bundledScript = settings.debug ? 'src/project.dev.js' : 'src/project.js';
    // if (jsList) {
    //     jsList = jsList.map(function (x) {
    //         return 'src/' + x;
    //     });
    //     jsList.push(bundledScript);
    // } else {
    //     jsList = [bundledScript];
    // }

    var option = {
        id: 'GameCanvas',
        scenes: settings.scenes,
        debugMode: settings.debug ? cc.debug.DebugMode.INFO : cc.debug.DebugMode.ERROR,
        showFPS: settings.debug,
        frameRate: 60,
        jsList: jsList,
        groupList: settings.groupList,
        collisionMatrix: settings.collisionMatrix,
    };

    // init assets
    cc.AssetLibrary.init({
        libraryPath: 'res/import',
        rawAssetsBase: 'res/raw-',
        rawAssets: settings.rawAssets,
        packedAssets: settings.packedAssets,
        md5AssetsMap: settings.md5AssetsMap,
        subpackages: settings.subpackages
    });
    cc.game.run(option, onStart);
};
window.boot();
window.Install = function () {
    console.log("crrent channels is facebook");
    try {
        FbPlayableAd.onCTAClick();
    } catch (e) {
        console.log("出现异常 本地测试请忽略此信息")
        console.log(e);
    }
};
window.onInteracted = function () {
    console.log("onInteracted");
    // parent.postMessage('interacted', "*");
};
window.onGameComplete = function () {
    console.log("onGameComplete");
    // parent.postMessage('complete', '*');
};
